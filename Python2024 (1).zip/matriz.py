#MATRIZ:
matriz = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]

for l in range(0, 3):
  for c in range(0, 3):
    matriz[l][c] = int(input(f'Digite um valor: [{l}, {c}]'))
print(matriz)
'''
'''
ELIF:
num1 = float(input("Primeiro sensor: "))
num2 = float(input("Segundo sensor: "))
media = (num1+num2)/2

if media >=30:
  print("Está muito quente!")
  print((num1+num2)/2)

elif media >=20:
  print("Está um pouco quente!")
  print((num1+num2)/2)

elif media >=10:
  print("Está um pouco frio!")
  print((num1+num2)/2)

else:
  print("Está muito frio!")
  print((num1+num2)/2)

print("\nFim do programa!!")