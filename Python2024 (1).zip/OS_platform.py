#Bibliotecas: OS e platform

import os
import platform

def check_file(file_name):
    # 1. Verifica se o arquivo existe
    if not os.path.exists(file_name):
        print(f"Erro: O arquivo '{file_name}' não existe.")
        return False

    # 2. Verifica se o arquivo não está vazio
    if os.path.getsize(file_name) == 0:
        print(f"Erro: O arquivo '{file_name}' está vazio.")
        return False

    # 3. Mostra o conteúdo do arquivo
    with open(file_name, 'r') as file:
        content = file.read()
        print(f"\nConteúdo do arquivo '{file_name}':\n{content}")

    # 4. Conta a quantidade de linhas do arquivo
    with open(file_name, 'r') as file:
        lines = file.readlines()
        print(f"\nQuantidade de linhas do arquivo '{file_name}': {len(lines)}")

    return True

#Exemplo
file_name = input("\nInforme o nome do arquivo (ex: exemplo.csv): ")
if check_file(file_name):
    print("\nOperação realizada com sucesso!")
else:
    print("\nErro ao processar o arquivo.")