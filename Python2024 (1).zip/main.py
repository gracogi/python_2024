#PYTHON - AULAS

print("PRIMEIROS PROGRAMAS - PYTHON 2024\n")
print('-' * 35)
print("EXEMPLO 01")
print("\n")

m = 'mensagem'
print(m)

m = 25
print(m)

m = 3.1416
print(m)

print("\n")
print('-' * 35)
print("EXEMPLO 02")
print("\n")

print("ACESSO AO SISTEMA\n")
login = input("Usuário: ")
senha = input("Senha: ")

print("\nSeu login é " + login + " e sua senha é " + senha)

print("\n")
print('-' * 35)
print("EXEMPLO 03")
print("\n")

v1 = int(input("Valor 1: "))
v2 = int(input("Valor 2: "))
#print("Soma = %s" %(v1+v2))
if v1 == v2:
  print("\nSão números iguais!")

else:
  print("\nSão números diferentes!")

print("\n")
print('-' * 35)
print("EXEMPLO 04")
print("\n")

print("SISTEMA DE NOTAS\n")
n1 = float(input("Informe a primeira nota: "))
n2 = float(input("Informe a segunda nota: "))

if (n1 + n2) / 2 >= 5:
  print("\nPassou primeira parte!")
  print((n1 + n2) / 2)
  if ((n1 + n2) / 2 >= 7):
    print("APROVADO!!")
    print((n1 + n2) / 2)

  else:
    print("\nAluno em exame!")
    print((n1 + n2) / 2)

else:
  print("\nAluno Reprovado!!")
  print((n1 + n2) / 2)

print("\n")
print('-' * 35)
print("FIM DO PROGRAMA!")

